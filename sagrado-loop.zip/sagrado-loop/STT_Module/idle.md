Speech to Text Module
