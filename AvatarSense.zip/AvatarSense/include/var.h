#include <Arduino.h>
#include <HardwareSerial.h>
#include <HTTPClient.h>
#include "WiFi.h"

// #define SSID "Segredo_EXT_EXT"
// #define PASSWORD "Amorada2020!"
#define SSID "Salto Do Sagrado_EXT"
#define PASSWORD "paraiso2023"
// #define SSID "HughesNet_6032B1"
// #define PASSWORD "HN57382C"
// #define SSID "informatica"
// #define PASSWORD "informatica453"

// String server_url = "https://plants.ifprinteligente.com.br/data/create";
String server_url = "http://apibiodata.sympoiesis.xyz/data/create";

float biodata1, biodata2, biodata3, biodata4, biodata5, biodata6, biodata7, biodata8, biodata9, biodata10, biodata11;