#include "var.h"

void wifiConnect() {
    
    WiFi.mode(WIFI_STA);
    WiFi.begin(SSID, PASSWORD);
    
    Serial.print("Connecting to WiFi Router.");
    while (WiFi.status() != WL_CONNECTED) {
        Serial.print(".");
        delay(1000);
    }

    Serial.print("Connected to the WiFi network: ");
    Serial.println(WiFi.localIP());
}

void sendAPI(float biodata1, float biodata2, float biodata3, float biodata4, float biodata5, float biodata6, float biodata7, float biodata8, float biodata9, float biodata10, float biodata11) {

    int httpResponseCode;
    HTTPClient http;


    if(WiFi.status() == WL_CONNECTED) {

        // String httpRequestData = "{\"sensor\":\"287\",\"press\":\"657.09\",\"humi\":\"49.54\",\"temp\":\"22.03\",\"gas\":\"4984\"}";
        String httpRequestData = "{\"biodata1\":\"";
        httpRequestData += biodata1;
        httpRequestData += "\",\"biodata2\":\"";
        httpRequestData += biodata2;
        httpRequestData += "\",\"biodata3\":\"";
        httpRequestData += biodata3;
        httpRequestData += "\",\"biodata4\":\"";
        httpRequestData += biodata4;
        httpRequestData += "\",\"biodata5\":\"";
        httpRequestData += biodata5;
        httpRequestData += "\",\"biodata6\":\"";
        httpRequestData += biodata6;
        httpRequestData += "\",\"biodata7\":\"";
        httpRequestData += biodata7;
        httpRequestData += "\",\"biodata8\":\"";
        httpRequestData += biodata8;
        httpRequestData += "\",\"biodata9\":\"";
        httpRequestData += biodata9;
        httpRequestData += "\",\"biodata10\":\"";
        httpRequestData += biodata10;
        httpRequestData += "\",\"biodata11\":\"";
        httpRequestData += biodata11;
        httpRequestData += "\"}";

        Serial.print(httpRequestData);

        http.begin(server_url);       
        http.addHeader("Content-Type", "application/json");
        httpResponseCode = http.POST(httpRequestData);
        Serial.print("HTTP Response code: ");
        Serial.println(httpResponseCode);
        http.end();
    }
}

void checkWiFi() {
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("WiFi disconnected, attempting reconnection...");
        WiFi.disconnect();  // Ensure we start fresh
        WiFi.begin(SSID, PASSWORD);

        // Wait for connection with a timeout
        int timeout = 0;
        while (WiFi.status() != WL_CONNECTED && timeout < 30) {  // 30 seconds timeout
            delay(1000);
            Serial.print(".");
            timeout++;
        }

        if (WiFi.status() == WL_CONNECTED) {
            Serial.println("Reconnected to WiFi.");
        } else {
            Serial.println("Failed to reconnect to WiFi.");
        }
    }
}
