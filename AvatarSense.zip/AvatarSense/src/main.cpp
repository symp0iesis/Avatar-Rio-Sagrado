#include "functions.h"
#include <Wire.h>
#include <SPI.h>
#include <Adafruit_Sensor.h>
#include "Adafruit_BME680.h"
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Adafruit_GFX.h>
#include <Adafruit_GC9A01A.h>

int moisturePin = A0;                 //OK moisture sensor
int icuPin = A1;                        //OK intercomunit sensor embutido
int WtempPin = A2;
int tdsPin = A3;
int null1 = A4;
int null2 = A5;

// Water temp sensor - Setup a oneWire instance to communicate with any OneWire devices
OneWire oneWire(WtempPin);
DallasTemperature sensors(&oneWire);

Adafruit_BME680 bme; // I2C

// Define the display pins
#define TFT_DC 5
#define TFT_CS 6
Adafruit_GC9A01A tft(TFT_CS, TFT_DC);

// Colors for sections
#define BG_COLOR GC9A01A_BLACK
#define TITLE_COLOR GC9A01A_WHITE
#define TEXT_COLOR GC9A01A_CYAN
#define VALUE_COLOR GC9A01A_BLUE

bool showAr = true;  // Toggle to switch between categories

void setup() {
  Serial.begin(9600);
  wifiConnect();

  // Pin initialization
  pinMode(moisturePin, INPUT);
  pinMode(icuPin, INPUT);
  pinMode(WtempPin, INPUT);
  pinMode(tdsPin, INPUT);

  //atmosphere sensor
  bme.begin();
  // Set up oversampling and filter initialization
  bme.setTemperatureOversampling(BME680_OS_8X);
  bme.setHumidityOversampling(BME680_OS_2X);
  bme.setPressureOversampling(BME680_OS_4X);
  bme.setIIRFilterSize(BME680_FILTER_SIZE_3);
  bme.setGasHeater(320, 150); // 320*C for 150 ms


  // DISPLAY
    // Initialize Display
  tft.begin();
  tft.setRotation(1);
  tft.fillScreen(GC9A01A_BLACK);
  delay(2000);
}

void displayCenteredText(const char *text, int y, uint16_t color, int size) {
  int16_t x1, y1;
  uint16_t w, h;
  tft.setTextSize(size);
  tft.getTextBounds(text, 0, y, &x1, &y1, &w, &h);
  int x = (tft.width() - w) / 2;  // Center horizontally
  tft.setCursor(x, y);
  tft.setTextColor(color);
  tft.println(text);
}

void displayAr() {
  tft.fillScreen(BG_COLOR);  // Clear the screen
  displayCenteredText("Ar", 20, TITLE_COLOR, 3);
  displayCenteredText("Temperatura", 70, TEXT_COLOR, 2);
  displayCenteredText(String(bme.temperature, 2).c_str(), 90, VALUE_COLOR, 4);
  displayCenteredText("Humidade", 150, TEXT_COLOR, 2);
  displayCenteredText(String(bme.humidity, 2).c_str(), 170, VALUE_COLOR, 4);
}

void displayAgua() {
  tft.fillScreen(BG_COLOR);  // Clear the screen
  displayCenteredText("Agua", 20, TITLE_COLOR, 3);
  displayCenteredText("Temperatura", 70, TEXT_COLOR, 2);
  displayCenteredText(String(sensors.getTempCByIndex(0), 2).c_str(), 90, VALUE_COLOR, 4);
  displayCenteredText("Condutividade", 150, TEXT_COLOR, 2);
  displayCenteredText(String(analogRead(tdsPin)).c_str(), 170, VALUE_COLOR, 4);
}

void loop() {

  // Check WiFi connection and reconnect if needed - https://chatgpt.com/c/6717ab25-1be4-800c-816d-2bd6c9c049d7
	checkWiFi();

  //atmosphere readings
  bme.performReading();
  biodata1 = bme.temperature;
  biodata2 = bme.humidity;
  biodata3 = bme.pressure/100.0;
  biodata4 = bme.gas_resistance;

 //Plant Sensors readings
  biodata5 = analogRead(icuPin);
  biodata6 = analogRead(moisturePin);

    //water sensors

  // Request DS18B20 temperature reading
  sensors.requestTemperatures();
  float waterTemp = sensors.getTempCByIndex(0); // Get temperature from DS18B20
  biodata7 = waterTemp;

  biodata8 = analogRead(tdsPin);
  biodata9 = analogRead(null1);
  biodata10 = analogRead(null2);
  biodata11 = 0;

  // Send data API
  sendAPI(biodata1, biodata2, biodata3, biodata4, biodata5, biodata6, biodata7, biodata8, biodata9, biodata10, biodata11);

  // Display the current category
  if (showAr) {
    displayAr();
  } else {
    displayAgua();
  }

  // Toggle for the next loop
  showAr = !showAr;

  // Wait for 5 seconds before switching
  delay(5000);
}